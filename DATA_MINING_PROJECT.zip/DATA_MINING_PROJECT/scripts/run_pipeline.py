import sys
import os
import matplotlib.pyplot as plt

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.data.loader import load_data
from src.data.cleaner import clean_data
from src.features.build_features import build_features
from src.mining.association import create_transactions, run_apriori
from src.mining.clustering import cluster_coins
from src.report.generate_report import generate_report

def main():

    # Load data
    df = load_data()

    print("Danh sách coin trong dataset:")
    print(df["Coin"].unique())
    print("Số lượng coin:", len(df["Coin"].unique()))

    # Clean data
    df = clean_data(df)

    # Association Rules
    transactions = create_transactions(df)
    rules = run_apriori(transactions)

    print("\nTop Association Rules:")
    print(rules.head())

    # Feature engineering
    features = build_features(df)

    # Clustering
    clusters = cluster_coins(features)

    print("\nCluster Results:")
    print(clusters)

    # Visualization
    os.makedirs("outputs", exist_ok=True)

    plt.figure(figsize=(8,6))

    plt.scatter(
        clusters["Return"],
        clusters["Volatility"],
        c=clusters["Cluster"]
    )

    for coin in clusters.index:
        plt.text(
            clusters.loc[coin,"Return"],
            clusters.loc[coin,"Volatility"],
            coin,
            fontsize=9
        )

    plt.xlabel("Return")
    plt.ylabel("Volatility")
    plt.title("Crypto Coin Clustering")

    plt.savefig("outputs/cluster_plot.png")

    plt.show()
    generate_report(rules, clusters)
    print("Analysis report saved to outputs/analysis_report.txt")

if __name__ == "__main__":
    main()