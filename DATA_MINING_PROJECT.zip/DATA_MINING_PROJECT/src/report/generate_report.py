def generate_report(rules, clusters):

    with open("outputs/analysis_report.txt", "w", encoding="utf-8") as f:

        f.write("CRYPTO DATA MINING ANALYSIS REPORT\n")
        f.write("="*40 + "\n\n")

        f.write("1. ASSOCIATION RULES (Top 5)\n")
        f.write("-"*40 + "\n")

        for i, row in rules.head().iterrows():

            f.write(
                f"{row['antecedents']} -> {row['consequents']} | "
                f"support={row['support']:.3f}, "
                f"confidence={row['confidence']:.3f}, "
                f"lift={row['lift']:.3f}\n"
            )

        f.write("\n")

        f.write("2. CLUSTERING RESULTS\n")
        f.write("-"*40 + "\n")

        for coin in clusters.index:

            r = clusters.loc[coin,"Return"]
            v = clusters.loc[coin,"Volatility"]
            c = clusters.loc[coin,"Cluster"]

            f.write(
                f"{coin}: Return={r:.5f}, Volatility={v:.5f}, Cluster={c}\n"
            )

        f.write("\n")

        f.write("3. INTERPRETATION\n")
        f.write("-"*40 + "\n")

        f.write(
            "Coins in the same cluster share similar return and volatility patterns.\n"
        )

        f.write(
            "Association rules indicate possible relationships between price movements of cryptocurrencies.\n"
        )

        f.write("\nReport generated automatically by Data Mining pipeline.\n")