import pandas as pd

def build_features(df):

    df["Return"] = df.groupby("Coin")["Close"].pct_change()

    features = df.groupby("Coin").agg(
        Return=("Return","mean"),
        Volatility=("Return","std")
    )

    features = features.fillna(0)

    return features