import pandas as pd
import glob
import os

def load_data(path="data/raw/*.csv"):

    files = glob.glob(path)

    dfs = []

    for file in files:

        # lấy tên coin từ filename
        coin = os.path.basename(file).replace(".csv","")

        df = pd.read_csv(file)

        df["Coin"] = coin

        dfs.append(df)

    data = pd.concat(dfs)

    data["Date"] = pd.to_datetime(data["Date"])

    data = data.sort_values(["Coin","Date"])

    return data