def clean_data(df):

    df = df.dropna()

    df["Date"] = df["Date"].astype(str)

    df = df.sort_values(["Coin","Date"])

    return df