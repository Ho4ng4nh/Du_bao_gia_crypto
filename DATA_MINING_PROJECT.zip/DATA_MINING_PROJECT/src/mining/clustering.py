from sklearn.cluster import KMeans

def cluster_coins(features):

    X = features[["Return","Volatility"]]

    model = KMeans(
        n_clusters=3,
        random_state=42
    )

    features["Cluster"] = model.fit_predict(X)

    return features