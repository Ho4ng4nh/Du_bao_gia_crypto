import pandas as pd
from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules


def create_transactions(df):

    df["Return"] = df.groupby("Coin")["Close"].pct_change()

    df["State"] = df["Return"].apply(
        lambda x: "UP" if x > 0 else "DOWN"
    )

    pivot = df.pivot_table(
        index="Date",
        columns="Coin",
        values="State",
        aggfunc="first"
    )

    transactions = pivot.apply(
        lambda row: [f"{coin}_{state}" for coin, state in row.items()],
        axis=1
    )

    from mlxtend.preprocessing import TransactionEncoder

    te = TransactionEncoder()

    te_array = te.fit(transactions).transform(transactions)

    df_encoded = pd.DataFrame(
        te_array,
        columns=te.columns_
    )

    return df_encoded


def run_apriori(transactions):

    freq = apriori(
        transactions,
        min_support=0.2,
        use_colnames=True
    )

    rules = association_rules(
        freq,
        metric="lift",
        min_threshold=1
    )

    return rules